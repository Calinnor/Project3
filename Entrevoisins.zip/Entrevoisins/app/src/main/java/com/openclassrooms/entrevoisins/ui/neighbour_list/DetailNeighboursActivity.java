package com.openclassrooms.entrevoisins.ui.neighbour_list;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.openclassrooms.entrevoisins.R;
import com.openclassrooms.entrevoisins.model.Neighbour;
import com.openclassrooms.entrevoisins.service.DummyNeighbourApiService;

public class DetailNeighboursActivity extends AppCompatActivity {

    private ImageButton mbackButton;
    private FloatingActionButton mFavoriteButton;
    private boolean mIsFavorite;
    private Button mTestIsFav;
    private TextView phone;
    private TextView adress;
    private TextView aboutMe;
    private TextView firstname;
    private TextView nameOnAvatar;
    private TextView mail;
    private ImageView avatar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_neighbours);

        mTestIsFav = findViewById(R.id.test_button_isFav);

        mFavoriteButton = findViewById(R.id.detail_add_favorite_neighbour_floating_button);

        mbackButton = findViewById(R.id.back_button);
        mbackButton.setOnClickListener(v -> DetailNeighboursActivity.this.finish());

        Intent intent = getIntent();
        Neighbour neighbour = intent.getParcelableExtra("Neighbours");

        boolean isFavorite = neighbour.isFavorite();
        mIsFavorite = isFavorite;

        String getPhone = neighbour.getPhoneNumber();
        phone = findViewById(R.id.detail_phone);
        phone.setText(getPhone);

        String getAdress = neighbour.getAddress();
        adress = findViewById(R.id.detail_adress);
        adress.setText(getAdress);

        String getAboutMe = neighbour.getAboutMe();
        aboutMe = findViewById(R.id.detail_about_me);
        aboutMe.setText(getAboutMe);

        String getFirstname =neighbour.getName();
        firstname = findViewById(R.id.detail_firstname);
        firstname.setText(getFirstname);

        nameOnAvatar = findViewById(R.id.detail_firstname_on_avatar_image);
        nameOnAvatar.setText(getFirstname);

        String getMail = neighbour.getName();
        mail = findViewById(R.id.detail_mail);
        mail.setText("www.facebook.com/"+getMail);

        String getAvatar = neighbour.getAvatarUrl();
        avatar = findViewById(R.id.detail_avatar_view);
        Glide.with(this)
                .load(getAvatar)
                .into(avatar);

        mFavoriteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mIsFavorite == true) {
                    mIsFavorite = false;
                    DummyNeighbourApiService.favoritesNeighbours.remove(neighbour);




                } else if (mIsFavorite == false) {
                    mIsFavorite = true;
                    mFavoriteButton.setImageResource(R.drawable.ic_star_gold_24dp);
                    DummyNeighbourApiService.favoritesNeighbours.add(neighbour);

                }
            }

        });

        mTestIsFav.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                onClickTo();
            }
        });
    }

    public void onClickTo () {
        Toast.makeText(this, "reponse +"+ mIsFavorite, Toast.LENGTH_LONG).show();
    }









}
